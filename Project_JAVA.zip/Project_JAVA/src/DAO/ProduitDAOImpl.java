package DAO;

// import des packages
import Modele.Produit;
import java.sql.*;
import java.util.ArrayList;

/**
 * implémentation MySQL du stockage dans la base de données des méthodes définies dans l'interface
 * ClientDao.
 */
public class ProduitDAOImpl implements ProduitDAO {
    // attribut privé pour l'objet du DaoFactoru
    private DaoFactory daoFactory;

    // constructeur dépendant de la classe DaoFactory
    public ProduitDAOImpl(DaoFactory daoFactory) {
        this.daoFactory = daoFactory;
    }

    @Override
    /**
     * Récupérer de la base de données tous les objets des clients dans une liste
     * @return : liste retournée des objets des clients récupérés
     */
    public ArrayList<Produit> getAll() {
        ArrayList<Produit> listeProduits = new ArrayList<Produit>();

        /*
            Récupérer la liste des clients de la base de données dans listeClients
        */
        try {
            // connexion
            Connection connexion = daoFactory.getConnection();;
            Statement statement = connexion.createStatement();
            ResultSet resultats = statement.executeQuery("select * from Produit");

            // 	Se déplacer sur le prochain enregistrement : retourne false si la fin est atteinte
            while (resultats.next()) {
                // récupérer les 3 champs de la table produits dans la base de données
                int idProduit = resultats.getInt("idProduit");
                String nom = resultats.getString("nom");
                String description = resultats.getString("description");
                double prixUnitaire = resultats.getDouble("prixUnitaire");
                double prixVrac = resultats.getDouble("prixVrac");
                int seuilVrac = resultats.getInt("seuilVrac");
                int idCategorie = resultats.getInt("idCategorie");

                // instancier un objet de Produit avec ces 3 champs en paramètres
                Produit produit = new Produit(idProduit, nom, description, prixUnitaire, prixVrac, seuilVrac, idCategorie);
                // ajouter ce produit à listeProduits
                listeProduits.add(produit);
            }
        }
        catch (SQLException e) {
            //traitement de l'exception
            e.printStackTrace();
            System.out.println("Impossicle de récupérer la liste des produits.");
        }

        return listeProduits;
    }

    public DaoFactory getDaoFactory() {
        return this.daoFactory;
    }

    /**
     Ajouter un nouveau produit en paramètre dans la base de données
     @params : produit = objet de Produit à insérer dans la base de données
     */
    @Override
    public void ajouter(Produit produit) {
        try {
            Connection connexion = daoFactory.getConnection();
            String sql = "INSERT INTO Produit(nom, description, prixUnitaire, prixVrac, seuilVrac, idCategorie) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = connexion.prepareStatement(sql);
            ps.setString(1, produit.getNom());
            ps.setString(2, produit.getDescription());
            ps.setDouble(3, produit.getPrixUnitaire());
            ps.setDouble(4, produit.getPrixVrac());
            ps.setInt(5, produit.getSeuilVrac());
            ps.setInt(6, produit.getIdCategorie());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Ajout du produit impossible");
        }
    }

    /**
     * Permet de chercher et récupérer un objet de Produit dans la base de données via son id en paramètre
     * @param : idProduit
     * @return : objet de classe Client cherché et retourné
     */

    @Override
    public Produit chercher(int idProduit)  {
        Produit produit = null;

        try {
            Connection connexion = daoFactory.getConnection();
            String sql = "SELECT * FROM Produit WHERE idProduit = ?";
            PreparedStatement ps = connexion.prepareStatement(sql);
            ps.setInt(1, idProduit);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                produit = new Produit(
                        rs.getInt("idProduit"),
                        rs.getString("nom"),
                        rs.getString("description"),
                        rs.getDouble("prixUnitaire"),
                        rs.getObject("prixVrac") != null ? rs.getDouble("prixVrac") : null,
                        rs.getObject("seuilVrac") != null ? rs.getInt("seuilVrac") : null,
                        rs.getInt("idCategorie")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Produit non trouvé dans la base de données");
        }
        return produit;
    }

    /**
     * Permet de modifier les données du nom de l'objet de la classe Client en paramètre
     * dans la base de données à partir de l'id de cet objet en paramètre
     * @param : client = objet en paramètre de la classe Client à mettre à jour à partir de son id
     * @return : objet client en paramètre mis à jour  dans la base de données à retourner
     */
    @Override
    public Produit modifier(Produit produit) {
        String sql = "UPDATE Produit SET nom = ?, description = ?, prixUnitaire = ?, prixVrac = ?, seuilVrac = ?, idCategorie = ? WHERE idProduit = ?";

        try (Connection connexion = daoFactory.getConnection();
             PreparedStatement ps = connexion.prepareStatement(sql)) {

            ps.setString(1, produit.getNom());
            ps.setString(2, produit.getDescription());
            ps.setDouble(3, produit.getPrixUnitaire());
            ps.setDouble(4, produit.getPrixVrac()); // sans test
            ps.setInt(5, produit.getSeuilVrac()); // sans test
            ps.setInt(6, produit.getIdCategorie());
            ps.setInt(7, produit.getIdProduit());

            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Modification du produit impossible.");
        }

        return produit;
    }

    /**
     * Supprimer un objet de la classe Client en paramètre dans la base de données en respectant la contrainte
     * d'intégrité référentielle : en supprimant un client, supprimer aussi en cascade toutes les commandes de la
     * table commander qui ont l'id du client supprimé.
     * @params : client = objet de Client en paramètre à supprimer de la base de données
     */
    @Override
    public void supprimer(Produit produit) {
        String sql = "DELETE FROM Produit WHERE idProduit = ?";

        try (Connection connexion = daoFactory.getConnection();
             PreparedStatement ps = connexion.prepareStatement(sql)) {

            ps.setInt(1, produit.getIdProduit());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Suppression du produit impossible.");
        }
    }
}
